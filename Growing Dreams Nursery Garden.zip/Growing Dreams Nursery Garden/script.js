fetch("./plants.json")
  .then((response) => response.json())
  .then((data) => displayPlants(data));

function displayPlants(plants) {
  const plantsSection = document.getElementById("plants");

  plants.forEach((plant) => {
    const plantItem = document.createElement("div");
    plantItem.classList.add("plant-item");

    plantItem.innerHTML = `
      <div class="plant-img">
        <img src="${plant.image}" alt="${plant.name}" />
      </div>
      <h2>${plant.name}</h2>
      <p>Price: $${plant.price.toFixed(2)}</p>
      <button class="buy-now" onclick="addToCart('${plant.name}', ${
      plant.price
    })">
        Buy Now
      </button>
    `;

    plantsSection.appendChild(plantItem);
  });
}

// variable to store cart items
let cartItems = [];

function addToCart(plantName, price) {
  // Create an object for the plant
  const plant = {
    name: plantName,
    price: price,
  };

  // Add the plant to the cart
  cartItems.push(plant);

  // Save the cart to localStorage
  localStorage.setItem("cart", JSON.stringify(cartItems));

  // Redirect to the cart page
  window.location.href = "cart.html";
}

// Display cart items on the cart page
document.addEventListener("DOMContentLoaded", function () {
  const contactForm = document.getElementById("contactForm");

  contactForm.addEventListener("submit", function (event) {
    event.preventDefault();
    showAlert("Details submitted successfully!");
  });

  function showAlert(message) {
    alert(message);
  }
});

// cart.js
let cartItems = [];

function displayCartItems() {
  const cartItemsDiv = document.getElementById("cartItems");

  // Retrieve cart items from localStorage
  const storedCart = localStorage.getItem("cart");
  if (storedCart) {
    cartItems = JSON.parse(storedCart);

    // Display each item in the cart
    cartItems.forEach((item) => {
      const cartItemDiv = document.createElement("div");
      cartItemDiv.classList.add("cart-item");
      cartItemDiv.innerHTML = `<p>${item.name} - $${item.price.toFixed(2)}</p>`;
      cartItemsDiv.appendChild(cartItemDiv);
    });
  }
}

function placeOrder() {
  // Clear the cart
  localStorage.removeItem("cart");

  // Hide the cart items
  const cartItemsDiv = document.getElementById("cartItems");
  cartItemsDiv.innerHTML = "";

  // Show the order confirmation message
  const orderConfirmationDiv = document.getElementById("orderConfirmation");
  orderConfirmationDiv.style.display = "block";

  // Hide the "Place Order" button after placing the order
  const placeOrderBtn = document.getElementById("placeOrderBtn");
  placeOrderBtn.style.display = "none";
}

function updatePlaceOrderButton() {
  const placeOrderBtn = document.getElementById("placeOrderBtn");
  const noItemsMessage = document.getElementById("noItemsMessage");

  // Show the "Place Order" button only if there are items in the cart
  placeOrderBtn.style.display = cartItems.length > 0 ? "block" : "none";

  if (cartItems.length > 0) {
    // Show the "Place Order" button
    placeOrderBtn.style.display = "block";

    // Hide the no items message
    noItemsMessage.style.display = "none";
  } else {
    // Hide the "Place Order" button
    placeOrderBtn.style.display = "none";

    // Show the no items message
    noItemsMessage.style.display = "block";
  }
}

// Call the necessary functions on page load
document.addEventListener("DOMContentLoaded", function () {
  displayCartItems();
  updatePlaceOrderButton();
});
